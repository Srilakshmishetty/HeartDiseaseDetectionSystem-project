package com.Heart.Disease.Detection.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeartDiseaseDetectionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
