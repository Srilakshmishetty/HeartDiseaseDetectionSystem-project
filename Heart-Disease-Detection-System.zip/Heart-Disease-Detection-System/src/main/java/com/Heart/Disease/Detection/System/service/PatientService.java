package com.Heart.Disease.Detection.System.service;

import com.Heart.Disease.Detection.System.entity.Patient;
import com.Heart.Disease.Detection.System.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {
	
	@Autowired
	private PatientRepository patientRepository;
	
	public List<Patient> getAllPatients(){
		return patientRepository.findAll();
	}
	
	public Patient savePatient (Patient patient) {
		return patientRepository.save(patient);
	}
	
	public void deletePatient(Long id) {
		patientRepository.deleteById(id);
	}

	public Patient updatePatient(Long id, Patient updatedPatient) {
		// TODO Auto-generated method stub
		return null;
	}

}
