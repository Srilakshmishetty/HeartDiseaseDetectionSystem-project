package com.Heart.Disease.Detection.System.controller;
import com.Heart.Disease.Detection.System.entity.Patient;
import com.Heart.Disease.Detection.System.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/Patients")
public class PatientController {
	@Autowired
	private PatientService patientService;
	@GetMapping
	public List<Patient>getAllPatients() {
		return patientService.getAllPatients();
	}
	@PostMapping
	public void createPatient(@RequestBody Patient patient ) {
	}
	
	@DeleteMapping("/{id}")
	public String deletePatient(@PathVariable Long id) {
		patientService.deletePatient(id);
		return ("Patient deleted with id : "+id);
	}

}
